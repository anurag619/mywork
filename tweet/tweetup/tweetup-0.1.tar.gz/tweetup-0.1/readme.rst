
Tweetup
--------

This script will tweet along with a image.


